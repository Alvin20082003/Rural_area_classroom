// RuralLearn Virtual Classroom Application
// Global state management
let currentUser = null;
let currentRole = null;
let currentPage = 'landing-page';
let liveClassTimer = null;
let isRecording = false;
let isMuted = false;
let isVideoOn = false;
let handRaised = false;
let networkStatus = 'good'; // good, poor, offline

// Sample data from the application_data_json
const appData = {
  subjects: [
    {
      id: 1,
      name: "Artificial Intelligence",
      code: "AI101",
      instructor: "Dr. Priya Sharma",
      description: "Introduction to AI concepts and machine learning"
    },
    {
      id: 2,
      name: "VLSI Design",
      code: "VLSI201",
      instructor: "Prof. Rajesh Kumar",
      description: "Very Large Scale Integration circuit design"
    },
    {
      id: 3,
      name: "Renewable Energy",
      code: "RE301",
      instructor: "Dr. Anita Patel",
      description: "Solar, wind and sustainable energy systems"
    },
    {
      id: 4,
      name: "Digital Marketing",
      code: "DM101",
      instructor: "Prof. Suresh Singh",
      description: "Modern marketing strategies and social media"
    }
  ],
  liveClasses: [
    {
      id: 1,
      subject: "Artificial Intelligence",
      instructor: "Dr. Priya Sharma",
      time: "2:00 PM - 3:30 PM",
      date: "Today",
      participants: 45,
      status: "live",
      duration: "90 min"
    },
    {
      id: 2,
      subject: "VLSI Design",
      instructor: "Prof. Rajesh Kumar",
      time: "4:00 PM - 5:00 PM",
      date: "Today",
      participants: 32,
      status: "upcoming",
      duration: "60 min"
    }
  ],
  recordings: [
    {
      id: 1,
      title: "Introduction to Machine Learning",
      subject: "Artificial Intelligence",
      instructor: "Dr. Priya Sharma",
      duration: "85 min",
      fileSize: "12 MB",
      date: "Sept 15, 2025",
      views: 127,
      downloadable: true
    },
    {
      id: 2,
      title: "CMOS Technology Basics",
      subject: "VLSI Design",
      instructor: "Prof. Rajesh Kumar",
      duration: "75 min",
      fileSize: "10 MB",
      date: "Sept 14, 2025",
      views: 89,
      downloadable: true
    },
    {
      id: 3,
      title: "Solar Panel Efficiency",
      subject: "Renewable Energy",
      instructor: "Dr. Anita Patel",
      duration: "60 min",
      fileSize: "8 MB",
      date: "Sept 13, 2025",
      views: 156,
      downloadable: true
    }
  ],
  students: [
    {
      name: "Rahul Verma",
      college: "Rural Polytechnic, Udaipur",
      subjects: ["AI", "Digital Marketing"],
      attendanceRate: 92
    },
    {
      name: "Priya Gupta",
      college: "Village Technical Institute, Bihar",
      subjects: ["VLSI", "Renewable Energy"],
      attendanceRate: 87
    },
    {
      name: "Amit Singh",
      college: "Rural Engineering College, UP",
      subjects: ["AI", "VLSI"],
      attendanceRate: 94
    }
  ],
  quizzes: [
    {
      id: 1,
      title: "AI Fundamentals Quiz",
      subject: "Artificial Intelligence",
      questions: [
        {
          question: "What does AI stand for?",
          options: ["Artificial Intelligence", "Advanced Integration", "Automated Interface", "Applied Innovation"],
          correct: 0
        },
        {
          question: "Which is a type of machine learning?",
          options: ["Supervised Learning", "Random Learning", "Fixed Learning", "Static Learning"],
          correct: 0
        }
      ]
    }
  ],
  polls: [
    {
      id: 1,
      question: "What time works best for evening classes?",
      options: ["6:00 PM", "7:00 PM", "8:00 PM", "9:00 PM"],
      votes: [15, 32, 28, 8]
    }
  ],
  bandwidthTips: [
    "Audio quality prioritized over video",
    "Content pre-compressed for faster loading",
    "Offline download available during low-traffic hours",
    "Text-based interactions use minimal data",
    "Smart caching reduces repeated downloads"
  ]
};

// Chat messages for live classroom
let chatMessages = [
  { sender: "Dr. Priya Sharma", text: "Welcome everyone to today's AI session!", time: "2:01 PM" },
  { sender: "Rahul Verma", text: "Thank you, excited to learn!", time: "2:02 PM" },
  { sender: "Priya Gupta", text: "Audio is clear, thank you", time: "2:03 PM" }
];

// Participants for live classroom
let participants = [
  { name: "Dr. Priya Sharma", role: "teacher", status: "speaking", muted: false },
  { name: "Rahul Verma", role: "student", status: "listening", muted: true },
  { name: "Priya Gupta", role: "student", status: "listening", muted: true },
  { name: "Amit Singh", role: "student", status: "hand-raised", muted: true },
  { name: "Sneha Patel", role: "student", status: "listening", muted: true }
];

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
  showPage('landing-page');
  simulateNetworkChanges();
  initializeBandwidthIndicator();
});

// Navigation functions
function showPage(pageId) {
  // Hide all pages
  const pages = document.querySelectorAll('.page');
  pages.forEach(page => {
    page.classList.remove('active');
  });
  
  // Show target page
  const targetPage = document.getElementById(pageId);
  if (targetPage) {
    targetPage.classList.add('active');
    currentPage = pageId;
  }
}

function showLanding() {
  showPage('landing-page');
}

function showRoleSelection() {
  showPage('role-selection');
}

function showLoginForm(role) {
  currentRole = role;
  showPage('login-form');
  
  const loginTitle = document.getElementById('login-title');
  const collegeGroup = document.getElementById('college-group');
  const subjectGroup = document.getElementById('subject-group');
  
  if (role === 'teacher') {
    loginTitle.textContent = 'Teacher Login';
    collegeGroup.querySelector('label').textContent = 'Institution/College';
    subjectGroup.querySelector('label').textContent = 'Primary Subject';
  } else {
    loginTitle.textContent = 'Student Login';
    collegeGroup.querySelector('label').textContent = 'College/Institution';
    subjectGroup.querySelector('label').textContent = 'Interested Subjects';
  }
}

function handleLogin(event) {
  event.preventDefault();
  
  const name = document.getElementById('name').value;
  const college = document.getElementById('college').value;
  const subject = document.getElementById('subject').value;
  
  currentUser = {
    name: name,
    college: college,
    subject: subject,
    role: currentRole
  };
  
  if (currentRole === 'teacher') {
    showTeacherDashboard();
  } else {
    showStudentDashboard();
  }
}

function logout() {
  currentUser = null;
  currentRole = null;
  showPage('landing-page');
}

// Teacher Dashboard Functions
function showTeacherDashboard() {
  showPage('teacher-dashboard');
  document.getElementById('teacher-name').textContent = `Welcome back, ${currentUser.name}`;
  
  // Load teacher sections
  loadTeacherSchedule();
  loadTeacherClasses();
  loadTeacherMaterials();
  loadStudentAnalytics();
}

function showTeacherSection(section) {
  // Hide all sections
  const sections = document.querySelectorAll('#teacher-dashboard .section');
  sections.forEach(sec => sec.classList.remove('active'));
  
  // Show target section
  document.getElementById(`teacher-${section}`).classList.add('active');
  
  // Update navigation
  const navBtns = document.querySelectorAll('#teacher-dashboard .nav-btn');
  navBtns.forEach(btn => btn.classList.remove('active'));
  event.target.classList.add('active');
}

function loadTeacherSchedule() {
  const scheduleContainer = document.getElementById('teacher-schedule');
  scheduleContainer.innerHTML = '';
  
  appData.liveClasses.forEach(classItem => {
    const classElement = document.createElement('div');
    classElement.className = 'class-item';
    classElement.innerHTML = `
      <div class="class-info">
        <h4>${classItem.subject}</h4>
        <div class="class-meta">
          <span>${classItem.time}</span>
          <span>•</span>
          <span>${classItem.participants} students</span>
          <span>•</span>
          <span class="status ${classItem.status}">${classItem.status}</span>
        </div>
      </div>
      <div class="class-actions">
        <button class="btn btn--primary btn--sm" onclick="joinTeacherClass(${classItem.id})">
          ${classItem.status === 'live' ? 'Join Class' : 'Start Class'}
        </button>
      </div>
    `;
    scheduleContainer.appendChild(classElement);
  });
}

function loadTeacherClasses() {
  const classesContainer = document.getElementById('teacher-classes-list');
  classesContainer.innerHTML = '';
  
  appData.liveClasses.forEach(classItem => {
    const classCard = document.createElement('div');
    classCard.className = 'class-card';
    classCard.innerHTML = `
      <div class="class-card-header">
        <h4>${classItem.subject}</h4>
        <span class="status ${classItem.status}">${classItem.status}</span>
      </div>
      <div class="class-card-body">
        <p><strong>Time:</strong> ${classItem.time}</p>
        <p><strong>Duration:</strong> ${classItem.duration}</p>
        <p><strong>Participants:</strong> ${classItem.participants} students</p>
      </div>
      <div class="class-card-footer">
        <button class="btn btn--primary btn--sm" onclick="joinTeacherClass(${classItem.id})">
          ${classItem.status === 'live' ? 'Join Class' : 'Start Class'}
        </button>
        <button class="btn btn--outline btn--sm" onclick="editClass(${classItem.id})">Edit</button>
      </div>
    `;
    classesContainer.appendChild(classCard);
  });
}

function loadTeacherMaterials() {
  const materialsContainer = document.getElementById('teacher-materials-list');
  materialsContainer.innerHTML = '';
  
  appData.recordings.forEach(recording => {
    const materialItem = document.createElement('div');
    materialItem.className = 'material-item';
    materialItem.innerHTML = `
      <span class="material-icon">🎥</span>
      <h4>${recording.title}</h4>
      <p class="material-size">${recording.fileSize} • ${recording.duration}</p>
      <div class="material-actions">
        <button class="btn btn--outline btn--sm" onclick="editMaterial(${recording.id})">Edit</button>
        <button class="btn btn--secondary btn--sm" onclick="downloadMaterial(${recording.id})">Download</button>
      </div>
    `;
    materialsContainer.appendChild(materialItem);
  });
}

function loadStudentAnalytics() {
  const topStudentsContainer = document.getElementById('top-students');
  topStudentsContainer.innerHTML = '';
  
  appData.students
    .sort((a, b) => b.attendanceRate - a.attendanceRate)
    .slice(0, 5)
    .forEach(student => {
      const studentItem = document.createElement('div');
      studentItem.className = 'student-item';
      studentItem.innerHTML = `
        <span class="student-name">${student.name}</span>
        <span class="student-attendance">${student.attendanceRate}%</span>
      `;
      topStudentsContainer.appendChild(studentItem);
    });
}

function joinTeacherClass(classId) {
  showLiveClassroom();
}

function createNewClass() {
  document.getElementById('create-class-modal').classList.remove('hidden');
}

function closeCreateClassModal() {
  document.getElementById('create-class-modal').classList.add('hidden');
}

function handleCreateClass(event) {
  event.preventDefault();
  showLiveClassroom();
  closeCreateClassModal();
}

function uploadMaterial() {
  alert('Material upload feature will open file picker in production environment');
}

function createQuiz() {
  alert('Quiz creation interface would open here');
}

function editClass(classId) {
  alert(`Edit class ${classId} - Would open class settings`);
}

function editMaterial(materialId) {
  alert(`Edit material ${materialId} - Would open material editor`);
}

function downloadMaterial(materialId) {
  const material = appData.recordings.find(r => r.id === materialId);
  if (material) {
    showNotification(`Downloading ${material.title} (${material.fileSize})...`, 'success');
  }
}

// Student Dashboard Functions
function showStudentDashboard() {
  showPage('student-dashboard');
  document.getElementById('student-name').textContent = `Welcome back, ${currentUser.name}`;
  
  loadStudentSchedule();
  loadStudentLiveClasses();
  loadStudentRecordings();
  loadStudentMaterials();
}

function showStudentSection(section) {
  // Hide all sections
  const sections = document.querySelectorAll('#student-dashboard .section');
  sections.forEach(sec => sec.classList.remove('active'));
  
  // Show target section
  document.getElementById(`student-${section}`).classList.add('active');
  
  // Update navigation
  const navBtns = document.querySelectorAll('#student-dashboard .nav-btn');
  navBtns.forEach(btn => btn.classList.remove('active'));
  event.target.classList.add('active');
}

function loadStudentSchedule() {
  const scheduleContainer = document.getElementById('student-schedule');
  scheduleContainer.innerHTML = '';
  
  appData.liveClasses.forEach(classItem => {
    const classElement = document.createElement('div');
    classElement.className = 'class-item';
    classElement.innerHTML = `
      <div class="class-info">
        <h4>${classItem.subject}</h4>
        <div class="class-meta">
          <span>${classItem.instructor}</span>
          <span>•</span>
          <span>${classItem.time}</span>
          <span>•</span>
          <span class="status ${classItem.status}">${classItem.status}</span>
        </div>
      </div>
      <div class="class-actions">
        <button class="btn btn--primary btn--sm" onclick="joinLiveClass(${classItem.id})">
          ${classItem.status === 'live' ? 'Join Now' : 'Set Reminder'}
        </button>
      </div>
    `;
    scheduleContainer.appendChild(classElement);
  });
}

function loadStudentLiveClasses() {
  const liveClassesContainer = document.getElementById('student-live-classes');
  liveClassesContainer.innerHTML = '';
  
  appData.liveClasses.forEach(classItem => {
    const classCard = document.createElement('div');
    classCard.className = 'class-card';
    classCard.innerHTML = `
      <div class="class-card-header">
        <h4>${classItem.subject}</h4>
        <span class="status ${classItem.status}">${classItem.status}</span>
      </div>
      <div class="class-card-body">
        <p><strong>Instructor:</strong> ${classItem.instructor}</p>
        <p><strong>Time:</strong> ${classItem.time}</p>
        <p><strong>Duration:</strong> ${classItem.duration}</p>
        <p><strong>Participants:</strong> ${classItem.participants} students</p>
      </div>
      <div class="class-card-footer">
        <button class="btn btn--primary btn--sm" onclick="joinLiveClass(${classItem.id})">
          ${classItem.status === 'live' ? 'Join Class' : 'Set Reminder'}
        </button>
      </div>
    `;
    liveClassesContainer.appendChild(classCard);
  });
}

function loadStudentRecordings() {
  const recordingsContainer = document.getElementById('student-recordings-list');
  recordingsContainer.innerHTML = '';
  
  appData.recordings.forEach(recording => {
    const recordingItem = document.createElement('div');
    recordingItem.className = 'recording-item';
    recordingItem.innerHTML = `
      <div class="recording-info">
        <h4>${recording.title}</h4>
        <div class="recording-meta">
          <span>${recording.instructor}</span>
          <span>•</span>
          <span>${recording.duration}</span>
          <span>•</span>
          <span>${recording.fileSize}</span>
          <span>•</span>
          <span>${recording.views} views</span>
        </div>
      </div>
      <div class="recording-actions">
        <button class="btn btn--primary btn--sm" onclick="playRecording(${recording.id})">▶️ Play</button>
        <button class="btn btn--outline btn--sm" onclick="downloadRecording(${recording.id})">⬇️ Download</button>
      </div>
    `;
    recordingsContainer.appendChild(recordingItem);
  });
}

function loadStudentMaterials() {
  const materialsContainer = document.getElementById('student-materials-list');
  materialsContainer.innerHTML = '';
  
  const materials = [
    { name: 'AI Lecture Notes', type: 'PDF', size: '2.5 MB' },
    { name: 'VLSI Lab Manual', type: 'PDF', size: '4.1 MB' },
    { name: 'Solar Energy Slides', type: 'PPT', size: '8.2 MB' },
    { name: 'Marketing Case Studies', type: 'DOC', size: '1.8 MB' }
  ];
  
  materials.forEach((material, index) => {
    const materialItem = document.createElement('div');
    materialItem.className = 'material-item';
    materialItem.innerHTML = `
      <span class="material-icon">📄</span>
      <h4>${material.name}</h4>
      <p class="material-size">${material.type} • ${material.size}</p>
      <button class="btn btn--primary btn--sm" onclick="downloadStudentMaterial(${index})">Download</button>
    `;
    materialsContainer.appendChild(materialItem);
  });
}

function joinLiveClass(classId) {
  const classData = appData.liveClasses.find(c => c.id === classId);
  if (classData && classData.status === 'live') {
    showLiveClassroom();
  } else {
    showNotification('Class reminder set! You will be notified when the class starts.', 'success');
  }
}

function playRecording(recordingId) {
  const recording = appData.recordings.find(r => r.id === recordingId);
  if (recording) {
    showAudioPlayer(recording);
  }
}

function downloadRecording(recordingId) {
  const recording = appData.recordings.find(r => r.id === recordingId);
  if (recording) {
    showNotification(`Downloading ${recording.title} (${recording.fileSize})...`, 'success');
  }
}

function downloadStudentMaterial(materialIndex) {
  showNotification('Starting download... Material will be available offline.', 'success');
}

function downloadMaterials() {
  showNotification('Downloading all course materials for offline access...', 'info');
}

// Live Classroom Functions
function showLiveClassroom() {
  showPage('live-classroom');
  
  // Set classroom info
  const liveClass = appData.liveClasses.find(c => c.status === 'live') || appData.liveClasses[0];
  document.getElementById('live-class-title').textContent = liveClass.subject;
  document.getElementById('live-instructor').textContent = liveClass.instructor;
  document.getElementById('live-participants').textContent = `${liveClass.participants} participants`;
  
  // Initialize classroom features
  startClassTimer();
  loadParticipants();
  loadChatMessages();
  loadPolls();
  
  // Reset controls
  isMuted = false;
  isVideoOn = false;
  handRaised = false;
  updateControlButtons();
}

function exitClassroom() {
  if (liveClassTimer) {
    clearInterval(liveClassTimer);
    liveClassTimer = null;
  }
  
  if (currentRole === 'teacher') {
    showTeacherDashboard();
  } else {
    showStudentDashboard();
  }
}

function startClassTimer() {
  let seconds = 0;
  liveClassTimer = setInterval(() => {
    seconds++;
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    const timeString = `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
    document.getElementById('live-duration').textContent = timeString;
  }, 1000);
}

// Audio/Video Controls
function toggleMute() {
  isMuted = !isMuted;
  updateControlButtons();
  
  if (isMuted) {
    showNotification('Microphone muted', 'info');
  } else {
    showNotification('Microphone unmuted', 'info');
  }
}

function toggleVideo() {
  isVideoOn = !isVideoOn;
  updateControlButtons();
  
  if (isVideoOn) {
    showNotification('Camera turned on', 'info');
  } else {
    showNotification('Camera turned off - Audio-first mode active', 'info');
  }
}

function raiseHand() {
  handRaised = !handRaised;
  updateControlButtons();
  
  if (handRaised) {
    showNotification('Hand raised - Teacher will be notified', 'success');
  } else {
    showNotification('Hand lowered', 'info');
  }
}

function toggleRecording() {
  if (currentRole !== 'teacher') {
    showNotification('Only teachers can control recording', 'warning');
    return;
  }
  
  isRecording = !isRecording;
  updateControlButtons();
  
  if (isRecording) {
    showNotification('Recording started', 'success');
  } else {
    showNotification('Recording stopped and saved', 'info');
  }
}

function updateControlButtons() {
  const muteBtn = document.getElementById('mute-btn');
  const videoBtn = document.getElementById('video-btn');
  const handBtn = document.getElementById('hand-btn');
  const recordBtn = document.getElementById('record-btn');
  
  // Update mute button
  muteBtn.className = `control-btn ${isMuted ? 'muted' : ''}`;
  muteBtn.innerHTML = `<span>${isMuted ? '🔇' : '🎤'}</span>`;
  
  // Update video button
  videoBtn.className = `control-btn ${isVideoOn ? 'active' : ''}`;
  videoBtn.innerHTML = `<span>${isVideoOn ? '📹' : '📷'}</span>`;
  
  // Update hand button
  handBtn.className = `control-btn ${handRaised ? 'active' : ''}`;
  handBtn.innerHTML = `<span>✋</span>`;
  
  // Update record button (teacher only)
  if (currentRole === 'teacher') {
    recordBtn.style.display = 'flex';
    recordBtn.className = `control-btn ${isRecording ? 'active' : ''}`;
    recordBtn.innerHTML = `<span>${isRecording ? '⏹️' : '⏺️'}</span>`;
  } else {
    recordBtn.style.display = 'none';
  }
}

// Sidebar Functions
function showSidebarTab(tabName) {
  // Hide all tab contents
  const tabContents = document.querySelectorAll('.tab-content');
  tabContents.forEach(content => content.classList.remove('active'));
  
  // Show target tab
  document.getElementById(`${tabName}-tab`).classList.add('active');
  
  // Update tab buttons
  const tabBtns = document.querySelectorAll('.tab-btn');
  tabBtns.forEach(btn => btn.classList.remove('active'));
  event.target.classList.add('active');
}

function loadParticipants() {
  const participantsList = document.getElementById('participants-list');
  participantsList.innerHTML = '';
  
  participants.forEach(participant => {
    const participantItem = document.createElement('div');
    participantItem.className = 'participant-item';
    
    const initials = participant.name.split(' ').map(n => n[0]).join('').toUpperCase();
    const statusIcon = participant.status === 'speaking' ? '🗣️' : 
                      participant.status === 'hand-raised' ? '✋' : '';
    
    participantItem.innerHTML = `
      <div class="participant-avatar">${initials}</div>
      <div class="participant-info">
        <div class="participant-name">${participant.name} ${statusIcon}</div>
        <div class="participant-status">${participant.status}</div>
      </div>
      <div class="participant-controls">
        <button title="${participant.muted ? 'Muted' : 'Unmuted'}">${participant.muted ? '🔇' : '🎤'}</button>
      </div>
    `;
    
    participantsList.appendChild(participantItem);
  });
}

// Chat Functions
function loadChatMessages() {
  const chatMessagesContainer = document.getElementById('chat-messages');
  chatMessagesContainer.innerHTML = '';
  
  chatMessages.forEach(message => {
    const messageElement = document.createElement('div');
    messageElement.className = 'chat-message';
    messageElement.innerHTML = `
      <div class="chat-sender">${message.sender}</div>
      <p class="chat-text">${message.text}</p>
    `;
    chatMessagesContainer.appendChild(messageElement);
  });
  
  // Scroll to bottom
  chatMessagesContainer.scrollTop = chatMessagesContainer.scrollHeight;
}

function handleChatInput(event) {
  if (event.key === 'Enter') {
    sendMessage();
  }
}

function sendMessage() {
  const chatInput = document.getElementById('chat-input');
  const message = chatInput.value.trim();
  
  if (message && currentUser) {
    chatMessages.push({
      sender: currentUser.name,
      text: message,
      time: new Date().toLocaleTimeString('en-US', { 
        hour: 'numeric', 
        minute: '2-digit', 
        hour12: true 
      })
    });
    
    chatInput.value = '';
    loadChatMessages();
  }
}

// Polls Functions
function loadPolls() {
  const pollsContainer = document.getElementById('polls-container');
  pollsContainer.innerHTML = '';
  
  appData.polls.forEach(poll => {
    const pollElement = document.createElement('div');
    pollElement.innerHTML = `
      <h4>${poll.question}</h4>
      <div class="poll-options">
        ${poll.options.map((option, index) => `
          <div class="poll-option" onclick="votePoll(${poll.id}, ${index})">
            <input type="radio" name="poll-${poll.id}" value="${index}">
            <span>${option}</span>
            <span>(${poll.votes[index]} votes)</span>
          </div>
        `).join('')}
      </div>
    `;
    pollsContainer.appendChild(pollElement);
  });
}

function votePoll(pollId, optionIndex) {
  const poll = appData.polls.find(p => p.id === pollId);
  if (poll) {
    poll.votes[optionIndex]++;
    loadPolls();
    showNotification('Vote recorded!', 'success');
  }
}

// Audio Player Functions
function showAudioPlayer(recording) {
  document.getElementById('audio-player').classList.remove('hidden');
  document.getElementById('audio-title').textContent = recording.title;
  document.getElementById('audio-subject').textContent = `Subject: ${recording.subject}`;
  document.getElementById('audio-instructor').textContent = `Instructor: ${recording.instructor}`;
  document.getElementById('audio-duration').textContent = `Duration: ${recording.duration}`;
}

function closeAudioPlayer() {
  document.getElementById('audio-player').classList.add('hidden');
}

function togglePlayPause() {
  const btn = event.target;
  if (btn.textContent.includes('Play')) {
    btn.innerHTML = '⏸️ Pause';
    startAudioProgress();
  } else {
    btn.innerHTML = '▶️ Play';
    // Stop progress simulation
  }
}

function startAudioProgress() {
  // Simulate audio progress
  let progress = 0;
  const interval = setInterval(() => {
    progress += 1;
    document.getElementById('audio-progress-fill').style.width = `${progress}%`;
    
    const currentTime = Math.floor((progress / 100) * 85 * 60); // 85 minutes
    const minutes = Math.floor(currentTime / 60);
    const seconds = currentTime % 60;
    document.getElementById('audio-time').textContent = 
      `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')} / 85:00`;
    
    if (progress >= 100) {
      clearInterval(interval);
      document.querySelector('[onclick="togglePlayPause()"]').innerHTML = '▶️ Play';
    }
  }, 500);
}

// Network Status Simulation
function simulateNetworkChanges() {
  // Simulate random network changes
  setInterval(() => {
    const statuses = ['good', 'poor', 'offline'];
    const newStatus = statuses[Math.floor(Math.random() * statuses.length)];
    
    if (newStatus !== networkStatus) {
      updateNetworkStatus(newStatus);
    }
  }, 30000); // Check every 30 seconds
}

function updateNetworkStatus(status) {
  networkStatus = status;
  
  const indicators = document.querySelectorAll('.bandwidth-indicator');
  indicators.forEach(indicator => {
    const dot = indicator.querySelector('.status-dot');
    const text = dot.nextElementSibling;
    
    dot.className = `status-dot ${status}`;
    
    switch (status) {
      case 'good':
        text.textContent = 'Good Connection';
        break;
      case 'poor':
        text.textContent = 'Poor Connection';
        showNetworkBanner('Poor connection detected. Switching to audio-only mode...');
        break;
      case 'offline':
        text.textContent = 'Offline Mode';
        showNetworkBanner('Connection lost. Using cached content...');
        break;
    }
  });
}

function showNetworkBanner(message) {
  const banner = document.getElementById('network-banner');
  const statusText = document.getElementById('network-status');
  
  statusText.textContent = message;
  banner.classList.remove('hidden');
  
  // Auto-hide after 5 seconds
  setTimeout(() => {
    banner.classList.add('hidden');
  }, 5000);
}

function closeNetworkBanner() {
  document.getElementById('network-banner').classList.add('hidden');
}

function initializeBandwidthIndicator() {
  // Set initial status to good
  updateNetworkStatus('good');
}

// Notification System
function showNotification(message, type = 'info') {
  // Create notification element
  const notification = document.createElement('div');
  notification.className = `notification notification--${type}`;
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: var(--color-surface);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-base);
    padding: var(--space-12) var(--space-16);
    box-shadow: var(--shadow-lg);
    z-index: 1002;
    max-width: 300px;
    font-size: var(--font-size-sm);
    animation: slideIn 0.3s ease-out;
  `;
  
  // Add type-specific styling
  switch (type) {
    case 'success':
      notification.style.borderColor = 'var(--color-success)';
      notification.style.background = 'rgba(var(--color-success-rgb), 0.1)';
      break;
    case 'warning':
      notification.style.borderColor = 'var(--color-warning)';
      notification.style.background = 'rgba(var(--color-warning-rgb), 0.1)';
      break;
    case 'error':
      notification.style.borderColor = 'var(--color-error)';
      notification.style.background = 'rgba(var(--color-error-rgb), 0.1)';
      break;
  }
  
  notification.textContent = message;
  document.body.appendChild(notification);
  
  // Auto-remove after 3 seconds
  setTimeout(() => {
    if (notification.parentNode) {
      notification.style.animation = 'slideOut 0.3s ease-in forwards';
      setTimeout(() => {
        notification.remove();
      }, 300);
    }
  }, 3000);
}

// Add CSS for notifications
const notificationCSS = `
@keyframes slideIn {
  from {
    transform: translateX(100%);
    opacity: 0;
  }
  to {
    transform: translateX(0);
    opacity: 1;
  }
}

@keyframes slideOut {
  from {
    transform: translateX(0);
    opacity: 1;
  }
  to {
    transform: translateX(100%);
    opacity: 0;
  }
}
`;

// Add the CSS to the document
const style = document.createElement('style');
style.textContent = notificationCSS;
document.head.appendChild(style);

// Accessibility Functions
document.addEventListener('keydown', function(event) {
  // ESC key closes modals
  if (event.key === 'Escape') {
    const openModals = document.querySelectorAll('.modal:not(.hidden)');
    openModals.forEach(modal => {
      if (modal.id === 'audio-player') {
        closeAudioPlayer();
      } else if (modal.id === 'create-class-modal') {
        closeCreateClassModal();
      }
    });
  }
  
  // Space bar for play/pause in audio player
  if (event.key === ' ' && currentPage === 'live-classroom') {
    event.preventDefault();
    // Toggle mute instead of play/pause for accessibility
    toggleMute();
  }
});

// Progressive Web App Features
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then(registration => {
        console.log('SW registered: ', registration);
      })
      .catch(registrationError => {
        console.log('SW registration failed: ', registrationError);
      });
  });
}

// Handle online/offline events
window.addEventListener('online', () => {
  updateNetworkStatus('good');
  showNotification('Connection restored!', 'success');
});

window.addEventListener('offline', () => {
  updateNetworkStatus('offline');
  showNotification('You are now offline. Cached content available.', 'info');
});

// Touch gesture support for mobile
let touchStartX = 0;
let touchStartY = 0;

document.addEventListener('touchstart', function(event) {
  touchStartX = event.touches[0].clientX;
  touchStartY = event.touches[0].clientY;
});

document.addEventListener('touchend', function(event) {
  if (!touchStartX || !touchStartY) return;
  
  const touchEndX = event.changedTouches[0].clientX;
  const touchEndY = event.changedTouches[0].clientY;
  
  const diffX = touchStartX - touchEndX;
  const diffY = touchStartY - touchEndY;
  
  // Horizontal swipe
  if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 50) {
    if (currentPage === 'live-classroom') {
      // Swipe to switch sidebar tabs
      const activeTab = document.querySelector('.tab-btn.active');
      if (activeTab) {
        const tabs = Array.from(document.querySelectorAll('.tab-btn'));
        const currentIndex = tabs.indexOf(activeTab);
        
        if (diffX > 0 && currentIndex < tabs.length - 1) {
          // Swipe left - next tab
          tabs[currentIndex + 1].click();
        } else if (diffX < 0 && currentIndex > 0) {
          // Swipe right - previous tab
          tabs[currentIndex - 1].click();
        }
      }
    }
  }
  
  touchStartX = 0;
  touchStartY = 0;
});

console.log('RuralLearn Virtual Classroom Application initialized successfully!');