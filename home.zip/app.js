// Application state
let currentUser = null;
let localStream = null;
let isCameraOn = false;
let isMicOn = false;

// Sample data from JSON
const sampleData = {
    subjects: [
        {
            id: 1,
            name: "Artificial Intelligence",
            code: "AI101",
            instructor: "Dr. Priya Sharma",
            description: "Introduction to AI concepts and machine learning",
            materials: [
                {
                    id: 1,
                    title: "AI Fundamentals - Introduction",
                    type: "pdf",
                    size: "2.4 MB",
                    description: "Complete guide to artificial intelligence basics",
                    downloadUrl: "data:application/pdf;base64,JVBERi0xLjQKMSAwIG9iago8PAovVHlwZSAvQ2F0YWxvZwovUGFnZXMgMiAwIFIKPj4KZW5kb2JqCjIgMCBvYmoKPDwKL1R5cGUgL1BhZ2VzCi9LaWRzIFszIDAgUl0KL0NvdW50IDEKPD4KZW5kb2JqCjMgMCBvYmoKPDwKL1R5cGUgL1BhZ2UKL1BhcmVudCAyIDAgUgovUmVzb3VyY2VzIDw8Ci9Gb250IDw8Ci9GMSA0IDAgUgo+Pgo+PgovTWVkaWFCb3ggWzAgMCA2MTIgNzkyXQovQ29udGVudHMgNSAwIFIKPj4KZW5kb2JqCjQgMCBvYmoKPDwKL1R5cGUgL0ZvbnQKL1N1YnR5cGUgL1R5cGUxCi9CYXNlRm9udCAvSGVsdmV0aWNhCj4+CmVuZG9iago1IDAgb2JqCjw8Ci9MZW5ndGggNDQKPj4Kc3RyZWFtCkJUCi9GMSAxMiBUZgoxMDAgNzAwIFRkCihTYW1wbGUgUERGIERvY3VtZW50KSBUagpFVApTdHJlYW0KZW5kb2JqCnhyZWYKMCA2CjAwMDAwMDAwMDAgNjU1MzUgZgowMDAwMDAwMDA5IDAwMDAwIG4KMDAwMDAwMDA1OCAwMDAwMCBuCjAwMDAwMDAxMTUgMDAwMDAgbgowMDAwMDAwMjQ1IDAwMDAwIG4KMDAwMDAwMDMxMiAwMDAwMCBuCnRyYWlsZXIKPDwKL1NpemUgNgovUm9vdCAxIDAgUgo+PgpzdGFydHhyZWYKNDA0CiUlRU9GCg=="
                },
                {
                    id: 2,
                    title: "Machine Learning Algorithms",
                    type: "image",
                    size: "856 KB",
                    description: "Visual guide to ML algorithms",
                    downloadUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="
                }
            ]
        },
        {
            id: 2,
            name: "VLSI Design",
            code: "VLSI201",
            instructor: "Prof. Rajesh Kumar",
            description: "Very Large Scale Integration circuit design",
            materials: [
                {
                    id: 3,
                    title: "CMOS Technology Basics",
                    type: "pdf",
                    size: "3.1 MB",
                    description: "CMOS technology fundamentals",
                    downloadUrl: "data:application/pdf;base64,JVBERi0xLjQKMSAwIG9iago8PAovVHlwZSAvQ2F0YWxvZwovUGFnZXMgMiAwIFIKPj4KZW5kb2JqCjIgMCBvYmoKPDwKL1R5cGUgL1BhZ2VzCi9LaWRzIFszIDAgUl0KL0NvdW50IDEKPD4KZW5kb2JqCjMgMCBvYmoKPDwKL1R5cGUgL1BhZ2UKL1BhcmVudCAyIDAgUgovUmVzb3VyY2VzIDw8Ci9Gb250IDw8Ci9GMSA0IDAgUgo+Pgo+PgovTWVkaWFCb3ggWzAgMCA2MTIgNzkyXQovQ29udGVudHMgNSAwIFIKPj4KZW5kb2JqCjQgMCBvYmoKPDwKL1R5cGUgL0ZvbnQKL1N1YnR5cGUgL1R5cGUxCi9CYXNlRm9udCAvSGVsdmV0aWNhCj4+CmVuZG9iago1IDAgb2JqCjw8Ci9MZW5ndGggNDQKPj4Kc3RyZWFtCkJUCi9GMSAxMiBUZgoxMDAgNzAwIFRkCihWTFNJIERvY3VtZW50KSBUagpFVApTdHJlYW0KZW5kb2JqCnhyZWYKMCA2CjAwMDAwMDAwMDAgNjU1MzUgZgowMDAwMDAwMDA5IDAwMDAwIG4KMDAwMDAwMDA1OCAwMDAwMCBuCjAwMDAwMDAxMTUgMDAwMDAgbgowMDAwMDAwMjQ1IDAwMDAwIG4KMDAwMDAwMDMxMiAwMDAwMCBuCnRyYWlsZXIKPDwKL1NpemUgNgovUm9vdCAxIDAgUgo+PgpzdGFydHhyZWYKNDA0CiUlRU9GCg=="
                }
            ]
        },
        {
            id: 3,
            name: "Renewable Energy",
            code: "RE301",
            instructor: "Dr. Anita Patel",
            description: "Solar, wind and sustainable energy systems",
            materials: [
                {
                    id: 4,
                    title: "Solar Panel Efficiency Guide",
                    type: "pdf",
                    size: "1.8 MB",
                    description: "Complete guide to solar panel technology",
                    downloadUrl: "data:application/pdf;base64,JVBERi0xLjQKMSAwIG9iago8PAovVHlwZSAvQ2F0YWxvZwovUGFnZXMgMiAwIFIKPj4KZW5kb2JqCjIgMCBvYmoKPDwKL1R5cGUgL1BhZ2VzCi9LaWRzIFszIDAgUl0KL0NvdW50IDEKPD4KZW5kb2JqCjMgMCBvYmoKPDwKL1R5cGUgL1BhZ2UKL1BhcmVudCAyIDAgUgovUmVzb3VyY2VzIDw8Ci9Gb250IDw8Ci9GMSA0IDAgUgo+Pgo+PgovTWVkaWFCb3ggWzAgMCA2MTIgNzkyXQovQ29udGVudHMgNSAwIFIKPj4KZW5kb2JqCjQgMCBvYmoKPDwKL1R5cGUgL0ZvbnQKL1N1YnR5cGUgL1R5cGUxCi9CYXNlRm9udCAvSGVsdmV0aWNhCj4+CmVuZG9iago1IDAgb2JqCjw8Ci9MZW5ndGggNDQKPj4Kc3RyZWFtCkJUCi9GMSAxMiBUZgoxMDAgNzAwIFRkCihTb2xhciBFbmVyZ3kgR3VpZGUpIFRqCkVUClN0cmVhbQplbmRvYmoKeHJlZgowIDYKMDAwMDAwMDAwMCA2NTUzNSBmCjAwMDAwMDAwMDkgMDAwMDAgbgowMDAwMDAwMDU4IDAwMDAwIG4KMDAwMDAwMDExNSAwMDAwMCBuCjAwMDAwMDAyNDUgMDAwMDAgbgowMDAwMDAwMzEyIDAwMDAwIG4KdHJhaWxlcgo8PAovU2l6ZSA2Ci9Sb290IDEgMCBSCj4+CnN0YXJ0eHJlZgo0MDQKJSVFT0YK"
                }
            ]
        }
    ],
    recordings: [
        {
            id: 1,
            title: "Introduction to Machine Learning",
            subject: "Artificial Intelligence",
            instructor: "Dr. Priya Sharma",
            duration: "45:32",
            fileSize: "87 MB",
            date: "Sept 15, 2025",
            views: 127,
            hasAudio: true,
            hasVideo: true,
            audioUrl: "data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFAxFn+Dsp2MdATJ+xfDXgzEAIHnM8N2TRAoRW7Pj56lZGw==",
            videoUrl: "data:video/mp4;base64,AAAAIGZ0eXBpc29tAAACAGlzb21pc28yYXZjMW1wNDEAAAAIZnJlZQAABvxtZGF0AAAC7wYF//+t3EXpvebZSLeWLNgg2SPu73gyNjQgLSBjb3JlIDE2NCByMzEwOCA3NTk5Mjk2IC0gSC4yNjQvTVBFRy00IEFWQyBjb2RlYyAtIENvcHlsZWZ0IDIwMDMtMjAyMyAtIGh0dHA6Ly93d3cudmlkZW9sYW4ub3JnL3gyNjQuaHRtbCAtIG9wdGlvbnM6IGNhYmFjPTEgcmVmPTMgZGVibG9jaz0xOjA6MCBhbmFseXNlPTB4MzoweDExMyBtZT1oZXggc3VibWU9NyBwc3k9MSBwc3lfcmQ9MS4wMDowLjAwIG1peGVkX3JlZj0xIG1lX3JhbmdlPTE2IGNocm9tYV9tZT0xIHRyZWxsaXM9MSA4eDhkY3Q9MSBjcW09MCBkZWFkem9uZT0yMSwxMSBmYXN0X3Bza2lwPTEgY2hyb21hX3FwX29mZnNldD0tMiB0aHJlYWRzPTMgbG9va2FoZWFkX3RocmVhZHM9MSBzbGljZWRfdGhyZWFkcz0wIG5yPTAgZGVjaW1hdGU9MSBpbnRlcmxhY2VkPTAgYmx1cmF5X2NvbXBhdD0wIGNvbnN0cmFpbmVkX2ludHJhPTAgYmZyYW1lcz0zIGJfcHlyYW1pZD0yIGJfYWRhcHQ9MSBiX2JpYXM9MCBkaXJlY3Q9MSB3ZWlnaHRiPTEgb3Blbl9nb3A9MCB3ZWlnaHRwPTIga2V5aW50PTI1MCBrZXlpbnRfbWluPTIwIHNjZW5lY3V0PTQwIGludHJhX3JlZnJlc2g9MCByY19sb29rYWhlYWQ9NDAgcmM9Y3JmIG1idHJlZT0xIGNyZj0yMy4wIHFjb21wPTAuNjAgcXBtaW49MCBxcG1heD02OSBxcHN0ZXA9NCBpcF9yYXRpbz0xLjQwIGFxPTE6MS4wMACAAAAAD2WIhAA3//728P4FNjuZQQAAAu5tb292AAAAbG12aGQAAAAAAAAAAAAAAAAAAAPoAAAAZAABAAABAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAACGHRyYWsAAABcdGtoZAAAAAMAAAAAAAAAAAAAAAEAAAAAAAAAZAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAEAAAAAAAgAAAAIAAAAAACRlZHRzAAAAHGVsc3QAAAAAAAAAAQAAAGQAAAAAAAEAAAAAAQhtZGlhAAAAIG1kaGQAAAAAAAAAAAAAAAAAADwAAAAEAFXEAAAAAAAtaGRscgAAAAAAAAAAdmlkZQAAAAAAAAAAAAAAAFZpZGVvSGFuZGxlcgAAAAE0bWluZgAAABR2bWhkAAAAAQAAAAAAAAAAAAAAJGRpbmYAAAAcZHJlZgAAAAAAAAABAAAADHVybCAAAAABAAAA9HN0YmwAAACYc3RzZAAAAAAAAAABAAAAiGF2YzEAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAgACAEgAAABIAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAY//8AAAA2YXZjQwFkAAr/4QAYZ2QACqzZX4XIllMLcBAAAPpAADqYA3YC3BXiRAAAABhzdHRzAAAAAAAAAAEAAAABAAAABAAAAAIAAAABc3RzegAAAAAAAAAAMgAAAAEAAAANAAAADWN0dHMAAAAAAAAADgAAAAIAAggAAAAAAgAEAAAAAQAAAAAAAAACAAgAAAABAAQAAAAEAAAABQAAAAEAAAAAAAAAAgAIAAAAAwAEAAAAIHN0c2MAAAAAAAAAAQAAAAEAAAACAAAAAQAAACBzdGNvAAAAAAAAAAIAAAAwAAAAOAAAABJzdHNzAAAAAAAAAAEAAAABAAAAGHNkdHAAAAAAcGFyZAAAAAAAAAABAAAAAmNvbHJuY2x4AAEAAQABAAAAFnVkdGEAAAAOZW5jAAAAAGFsYWMAAAAAAA==",
            description: "Complete introduction to ML concepts with practical examples"
        },
        {
            id: 2,
            title: "CMOS Circuit Analysis",
            subject: "VLSI Design",
            instructor: "Prof. Rajesh Kumar",
            duration: "52:18",
            fileSize: "96 MB",
            date: "Sept 14, 2025",
            views: 89,
            hasAudio: true,
            hasVideo: true,
            audioUrl: "data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFAxFn+Dsp2MdATJ+xfDXgzEAIHnM8N2TRAoRW7Pj56lZGw==",
            videoUrl: "data:video/mp4;base64,AAAAIGZ0eXBpc29tAAACAGlzb21pc28yYXZjMW1wNDEAAAAIZnJlZQAABvxtZGF0AAAC7wYF//+t3EXpvebZSLeWLNgg2SPu73gyNjQgLSBjb3JlIDE2NCByMzEwOCA3NTk5Mjk2IC0gSC4yNjQvTVBFRy00IEFWQyBjb2RlYyAtIENvcHlsZWZ0IDIwMDMtMjAyMyAtIGh0dHA6Ly93d3cudmlkZW9sYW4ub3JnL3gyNjQuaHRtbCAtIG9wdGlvbnM6IGNhYmFjPTEgcmVmPTMgZGVibG9jaz0xOjA6MCBhbmFseXNlPTB4MzoweDExMyBtZT1oZXggc3VibWU9NyBwc3k9MSBwc3lfcmQ9MS4wMDowLjAwIG1peGVkX3JlZj0xIG1lX3JhbmdlPTE2IGNocm9tYV9tZT0xIHRyZWxsaXM9MSA4eDhkY3Q9MSBjcW09MCBkZWFkem9uZT0yMSwxMSBmYXN0X3Bza2lwPTEgY2hyb21hX3FwX29mZnNldD0tMiB0aHJlYWRzPTMgbG9va2FoZWFkX3RocmVhZHM9MSBzbGljZWRfdGhyZWFkcz0wIG5yPTAgZGVjaW1hdGU9MSBpbnRlcmxhY2VkPTAgYmx1cmF5X2NvbXBhdD0wIGNvbnN0cmFpbmVkX2ludHJhPTAgYmZyYW1lcz0zIGJfcHlyYW1pZD0yIGJfYWRhcHQ9MSBiX2JpYXM9MCBkaXJlY3Q9MSB3ZWlnaHRiPTEgb3Blbl9nb3A9MCB3ZWlnaHRwPTIga2V5aW50PTI1MCBrZXlpbnRfbWluPTIwIHNjZW5lY3V0PTQwIGludHJhX3JlZnJlc2g9MCByY19sb29rYWhlYWQ9NDAgcmM9Y3JmIG1idHJlZT0xIGNyZj0yMy4wIHFjb21wPTAuNjAgcXBtaW49MCBxcG1heD02OSBxcHN0ZXA9NCBpcF9yYXRpbz0xLjQwIGFxPTE6MS4wMACAAAAAD2WIhAA3//728P4FNjuZQQAAAu5tb292AAAAbG12aGQAAAAAAAAAAAAAAAAAAAPoAAAAZAABAAABAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAACGHRyYWsAAABcdGtoZAAAAAMAAAAAAAAAAAAAAAEAAAAAAAAAZAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAEAAAAAAAgAAAAIAAAAAACRlZHRzAAAAHGVsc3QAAAAAAAAAAQAAAGQAAAAAAAEAAAAAAQhtZGlhAAAAIG1kaGQAAAAAAAAAAAAAAAAAADwAAAAEAFXEAAAAAAAtaGRscgAAAAAAAAAAdmlkZQAAAAAAAAAAAAAAAFZpZGVvSGFuZGxlcgAAAAE0bWluZgAAABR2bWhkAAAAAQAAAAAAAAAAAAAAJGRpbmYAAAAcZHJlZgAAAAAAAAABAAAADHVybCAAAAABAAAA9HN0YmwAAACYc3RzZAAAAAAAAAABAAAAiGF2YzEAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAgACAEgAAABIAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAY//8AAAA2YXZjQwFkAAr/4QAYZ2QACqzZX4XIllMLcBAAAPpAADqYA3YC3BXiRAAAABhzdHRzAAAAAAAAAAEAAAABAAAABAAAAAIAAAABc3RzegAAAAAAAAAAMgAAAAEAAAANAAAADWN0dHMAAAAAAAAADgAAAAIAAggAAAAAAgAEAAAAAQAAAAAAAAACAAgAAAABAAQAAAAEAAAABQAAAAEAAAAAAAAAAgAIAAAAAwAEAAAAIHN0c2MAAAAAAAAAAQAAAAEAAAACAAAAAQAAACBzdGNvAAAAAAAAAAIAAAAwAAAAOAAAABJzdHNzAAAAAAAAAAEAAAABAAAAGHNkdHAAAAAAcGFyZAAAAAAAAAABAAAAAmNvbHJuY2x4AAEAAQABAAAAFnVkdGEAAAAOZW5jAAAAAGFsYWMAAAAAAA==",
            description: "Detailed analysis of CMOS circuit design principles"
        },
        {
            id: 3,
            title: "Solar Energy Systems",
            subject: "Renewable Energy",
            instructor: "Dr. Anita Patel",
            duration: "38:45",
            fileSize: "72 MB",
            date: "Sept 13, 2025",
            views: 156,
            hasAudio: true,
            hasVideo: true,
            audioUrl: "data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFAxFn+Dsp2MdATJ+xfDXgzEAIHnM8N2TRAoRW7Pj56lZGw==",
            videoUrl: "data:video/mp4;base64,AAAAIGZ0eXBpc29tAAACAGlzb21pc28yYXZjMW1wNDEAAAAIZnJlZQAABvxtZGF0AAAC7wYF//+t3EXpvebZSLeWLNgg2SPu73gyNjQgLSBjb3JlIDE2NCByMzEwOCA3NTk5Mjk2IC0gSC4yNjQvTVBFRy00IEFWQyBjb2RlYyAtIENvcHlsZWZ0IDIwMDMtMjAyMyAtIGh0dHA6Ly93d3cudmlkZW9sYW4ub3JnL3gyNjQuaHRtbCAtIG9wdGlvbnM6IGNhYmFjPTEgcmVmPTMgZGVibG9jaz0xOjA6MCBhbmFseXNlPTB4MzoweDExMyBtZT1oZXggc3VibWU9NyBwc3k9MSBwc3lfcmQ9MS4wMDowLjAwIG1peGVkX3JlZj0xIG1lX3JhbmdlPTE2IGNocm9tYV9tZT0xIHRyZWxsaXM9MSA4eDhkY3Q9MSBjcW09MCBkZWFkem9uZT0yMSwxMSBmYXN0X3Bza2lwPTEgY2hyb21hX3FwX29mZnNldD0tMiB0aHJlYWRzPTMgbG9va2FoZWFkX3RocmVhZHM9MSBzbGljZWRfdGhyZWFkcz0wIG5yPTAgZGVjaW1hdGU9MSBpbnRlcmxhY2VkPTAgYmx1cmF5X2NvbXBhdD0wIGNvbnN0cmFpbmVkX2ludHJhPTAgYmZyYW1lcz0zIGJfcHlyYW1pZD0yIGJfYWRhcHQ9MSBiX2JpYXM9MCBkaXJlY3Q9MSB3ZWlnaHRiPTEgb3Blbl9nb3A9MCB3ZWlnaHRwPTIga2V5aW50PTI1MCBrZXlpbnRfbWluPTIwIHNjZW5lY3V0PTQwIGludHJhX3JlZnJlc2g9MCByY19sb29rYWhlYWQ9NDAgcmM9Y3JmIG1idHJlZT0xIGNyZj0yMy4wIHFjb21wPTAuNjAgcXBtaW49MCBxcG1heD02OSBxcHN0ZXA9NCBpcF9yYXRpbz0xLjQwIGFxPTE6MS4wMACAAAAAD2WIhAA3//728P4FNjuZQQAAAu5tb292AAAAbG12aGQAAAAAAAAAAAAAAAAAAAPoAAAAZAABAAABAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAACGHRyYWsAAABcdGtoZAAAAAMAAAAAAAAAAAAAAAEAAAAAAAAAZAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAEAAAAAAAgAAAAIAAAAAACRlZHRzAAAAHGVsc3QAAAAAAAAAAQAAAGQAAAAAAAEAAAAAAQhtZGlhAAAAIG1kaGQAAAAAAAAAAAAAAAAAADwAAAAEAFXEAAAAAAAtaGRscgAAAAAAAAAAdmlkZQAAAAAAAAAAAAAAAFZpZGVvSGFuZGxlcgAAAAE0bWluZgAAABR2bWhkAAAAAQAAAAAAAAAAAAAAJGRpbmYAAAAcZHJlZgAAAAAAAAABAAAADHVybCAAAAABAAAA9HN0YmwAAACYc3RzZAAAAAAAAAABAAAAiGF2YzEAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAgACAEgAAABIAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAY//8AAAA2YXZjQwFkAAr/4QAYZ2QACqzZX4XIllMLcBAAAPpAADqYA3YC3BXiRAAAABhzdHRzAAAAAAAAAAEAAAABAAAABAAAAAIAAAABc3RzewAAAAAAAAAAMgAAAAEAAAANAAAADWN0dHMAAAAAAAAADgAAAAIAAggAAAAAAgAEAAAAAQAAAAAAAAACAAgAAAABAAQAAAAEAAAABQAAAAEAAAAAAAAAAgAIAAAAAwAEAAAAIHN0c2MAAAAAAAAAAQAAAAEAAAACAAAAAQAAACBzdGNvAAAAAAAAAAIAAAAwAAAAOAAAABJzdHNzAAAAAAAAAAEAAAABAAAAGHNkdHAAAAAAcGFyZAAAAAAAAAABAAAAAmNvbHJuY2x4AAEAAQABAAAAFnVkdGEAAAAOZW5jAAAAAGFsYWMAAAAAAA==",
            description: "Comprehensive overview of solar energy technology"
        }
    ],
    quizzes: [
        {
            id: 1,
            title: "AI Fundamentals Quiz",
            subject: "Artificial Intelligence",
            instructor: "Dr. Priya Sharma",
            questions: [
                {
                    id: 1,
                    question: "What does AI stand for?",
                    options: ["Artificial Intelligence", "Advanced Integration", "Automated Interface", "Applied Innovation"],
                    correct: 0,
                    explanation: "AI stands for Artificial Intelligence, the simulation of human intelligence in machines."
                },
                {
                    id: 2,
                    question: "Which is a type of machine learning?",
                    options: ["Supervised Learning", "Random Learning", "Fixed Learning", "Static Learning"],
                    correct: 0,
                    explanation: "Supervised Learning is a fundamental type of machine learning where algorithms learn from labeled training data."
                }
            ]
        }
    ],
    users: [
        {
            id: "teacher_1",
            name: "Dr. Priya Sharma",
            email: "priya@ruralcollege.edu",
            role: "teacher",
            college: "Rural Technical Institute",
            subjects: ["Artificial Intelligence", "Machine Learning"]
        },
        {
            id: "student_1",
            name: "Rahul Verma",
            email: "rahul@student.edu",
            role: "student",
            college: "Rural Technical Institute",
            subjects: ["Artificial Intelligence", "VLSI Design"]
        }
    ]
};

// Utility functions
function showScreen(screenId) {
    // Hide all screens
    const screens = document.querySelectorAll('.screen');
    screens.forEach(screen => {
        screen.classList.remove('active');
        screen.classList.add('hidden');
    });
    
    // Show target screen
    const targetScreen = document.getElementById(screenId);
    if (targetScreen) {
        targetScreen.classList.remove('hidden');
        targetScreen.classList.add('active');
    }
}

function showToast(message, type = 'success') {
    const toastId = type === 'download' ? 'downloadToast' : 'uploadToast';
    const toast = document.getElementById(toastId);
    const messageEl = toast.querySelector('.toast-message');
    
    messageEl.textContent = message;
    toast.classList.remove('hidden');
    toast.classList.add('show');
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.classList.add('hidden'), 300);
    }, 3000);
}

function downloadFile(url, filename) {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    showToast('Download completed!', 'download');
}

// Camera functions
async function initCamera() {
    try {
        const constraints = {
            video: { width: 1280, height: 720 },
            audio: true
        };
        
        localStream = await navigator.mediaDevices.getUserMedia(constraints);
        const localVideo = document.getElementById('localVideo');
        const placeholder = document.getElementById('cameraPlaceholder');
        
        localVideo.srcObject = localStream;
        localVideo.classList.add('active');
        placeholder.style.display = 'none';
        
        isCameraOn = true;
        document.getElementById('toggleCamera').textContent = 'Turn Off Camera';
        showCameraStatus('Camera is on and ready for live class', 'success');
        
    } catch (error) {
        console.error('Error accessing camera:', error);
        let errorMessage = 'Unable to access camera. ';
        
        if (error.name === 'NotAllowedError') {
            errorMessage += 'Please allow camera access and try again.';
        } else if (error.name === 'NotFoundError') {
            errorMessage += 'No camera device found.';
        } else {
            errorMessage += 'Please check camera permissions.';
        }
        
        showCameraStatus(errorMessage, 'error');
    }
}

function stopCamera() {
    if (localStream) {
        localStream.getTracks().forEach(track => track.stop());
        localStream = null;
    }
    
    const localVideo = document.getElementById('localVideo');
    const placeholder = document.getElementById('cameraPlaceholder');
    
    localVideo.classList.remove('active');
    placeholder.style.display = 'flex';
    
    isCameraOn = false;
    document.getElementById('toggleCamera').textContent = 'Turn On Camera';
    showCameraStatus('Camera is turned off', 'warning');
}

function showCameraStatus(message, type) {
    const statusEl = document.getElementById('cameraStatus');
    statusEl.textContent = message;
    statusEl.className = `status-message ${type}`;
}

// File upload functions
function setupFileUpload() {
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('fileInput');
    
    if (!dropZone || !fileInput) return;
    
    dropZone.addEventListener('click', () => fileInput.click());
    
    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('dragover');
    });
    
    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('dragover');
    });
    
    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('dragover');
        const files = e.dataTransfer.files;
        handleFileUpload(files);
    });
    
    fileInput.addEventListener('change', (e) => {
        handleFileUpload(e.target.files);
    });
}

function handleFileUpload(files) {
    Array.from(files).forEach(file => {
        uploadFile(file);
    });
}

function uploadFile(file) {
    const uploadProgress = document.getElementById('uploadProgress');
    const progressFill = document.getElementById('progressFill');
    const progressText = document.getElementById('progressText');
    
    uploadProgress.classList.remove('hidden');
    
    // Simulate upload progress
    let progress = 0;
    const interval = setInterval(() => {
        progress += Math.random() * 15;
        if (progress > 100) progress = 100;
        
        progressFill.style.width = progress + '%';
        progressText.textContent = `Uploading ${file.name}... ${Math.round(progress)}%`;
        
        if (progress >= 100) {
            clearInterval(interval);
            setTimeout(() => {
                uploadProgress.classList.add('hidden');
                addUploadedMaterial(file);
                showToast(`${file.name} uploaded successfully!`);
                progressFill.style.width = '0%';
            }, 500);
        }
    }, 100);
}

function addUploadedMaterial(file) {
    const materialsList = document.getElementById('materialsList');
    if (!materialsList) return;
    
    const fileType = getFileType(file.name);
    const icon = getFileIcon(fileType);
    
    // Create a sample download URL for the uploaded file
    const reader = new FileReader();
    reader.onload = function(e) {
        const material = {
            id: Date.now(),
            title: file.name,
            type: fileType,
            size: formatFileSize(file.size),
            description: `Uploaded file: ${file.name}`,
            downloadUrl: e.target.result
        };
        
        const materialCard = createMaterialCard(material);
        materialsList.appendChild(materialCard);
    };
    reader.readAsDataURL(file);
}

function getFileType(filename) {
    const extension = filename.split('.').pop().toLowerCase();
    const types = {
        pdf: 'pdf',
        doc: 'document',
        docx: 'document',
        ppt: 'presentation',
        pptx: 'presentation',
        jpg: 'image',
        jpeg: 'image',
        png: 'image',
        mp4: 'video',
        mp3: 'audio',
        wav: 'audio'
    };
    return types[extension] || 'file';
}

function getFileIcon(type) {
    const icons = {
        pdf: '📄',
        document: '📝',
        presentation: '📊',
        image: '🖼️',
        video: '🎥',
        audio: '🎵',
        file: '📁'
    };
    return icons[type] || '📁';
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Material card creation
function createMaterialCard(material) {
    const card = document.createElement('div');
    card.className = 'material-card';
    card.setAttribute('data-type', material.type);
    
    card.innerHTML = `
        <div class="material-header">
            <div class="material-icon">${getFileIcon(material.type)}</div>
            <div class="material-info">
                <h4>${material.title}</h4>
                <div class="material-meta">${material.size} • ${material.type.toUpperCase()}</div>
                <p class="mb-0">${material.description}</p>
            </div>
        </div>
        <div class="material-actions">
            <button class="btn btn--primary btn--sm" onclick="downloadFile('${material.downloadUrl}', '${material.title}')">
                📥 Download
            </button>
            <button class="btn btn--outline btn--sm" onclick="viewMaterial('${material.downloadUrl}', '${material.type}')">
                👁️ View
            </button>
        </div>
    `;
    
    return card;
}

function createRecordingCard(recording) {
    const card = document.createElement('div');
    card.className = 'recording-card';
    
    card.innerHTML = `
        <div class="recording-header">
            <div class="recording-icon">🎥</div>
            <div class="recording-info">
                <h4>${recording.title}</h4>
                <div class="recording-meta">${recording.duration} • ${recording.fileSize} • ${recording.views} views</div>
                <p class="mb-0">${recording.description}</p>
                <div class="recording-meta">${recording.instructor} • ${recording.date}</div>
            </div>
        </div>
        <div class="recording-actions">
            <button class="btn btn--primary btn--sm" onclick="playRecording(${recording.id})">
                ▶️ Play
            </button>
            <button class="btn btn--outline btn--sm" onclick="downloadFile('${recording.videoUrl}', '${recording.title}.mp4')">
                📥 Download
            </button>
        </div>
    `;
    
    return card;
}

function createCourseCard(course) {
    const card = document.createElement('div');
    card.className = 'course-card';
    
    card.innerHTML = `
        <div class="course-header">
            <div class="course-icon">📚</div>
            <div class="course-info">
                <h4>${course.name}</h4>
                <div class="course-meta">${course.code} • ${course.instructor}</div>
                <p class="mb-0">${course.description}</p>
                <div class="course-meta">${course.materials.length} materials available</div>
            </div>
        </div>
        <div class="course-actions">
            <button class="btn btn--primary btn--sm" onclick="viewCourse(${course.id})">
                📖 View Materials
            </button>
        </div>
    `;
    
    return card;
}

function createQuizCard(quiz) {
    const card = document.createElement('div');
    card.className = 'quiz-card';
    
    card.innerHTML = `
        <div class="quiz-header">
            <div class="quiz-icon">❓</div>
            <div class="quiz-info">
                <h4>${quiz.title}</h4>
                <div class="quiz-meta">${quiz.subject} • ${quiz.instructor}</div>
                <p class="mb-0">${quiz.questions.length} questions</p>
            </div>
        </div>
        <div class="quiz-actions">
            <button class="btn btn--primary btn--sm" onclick="startQuiz(${quiz.id})">
                🎯 Take Quiz
            </button>
        </div>
    `;
    
    return card;
}

// Recording player functions
function playRecording(recordingId) {
    const recording = sampleData.recordings.find(r => r.id === recordingId);
    if (!recording) return;
    
    const modal = document.getElementById('recordingModal');
    const title = document.getElementById('recordingTitle');
    const video = document.getElementById('recordingVideo');
    const audio = document.getElementById('recordingAudio');
    const info = document.getElementById('recordingInfo');
    
    title.textContent = recording.title;
    info.textContent = `${recording.instructor} • ${recording.duration} • ${recording.date}`;
    
    // Show video player if available, otherwise show audio player
    if (recording.hasVideo && recording.videoUrl) {
        video.src = recording.videoUrl;
        video.style.display = 'block';
        audio.style.display = 'none';
    } else if (recording.hasAudio && recording.audioUrl) {
        audio.src = recording.audioUrl;
        audio.style.display = 'block';
        video.style.display = 'none';
    }
    
    modal.classList.remove('hidden');
}

// Quiz functions
function startQuiz(quizId) {
    const quiz = sampleData.quizzes.find(q => q.id === quizId);
    if (!quiz) return;
    
    const modal = document.getElementById('quizModal');
    const title = document.getElementById('quizTitle');
    const content = document.getElementById('quizContent');
    
    title.textContent = quiz.title;
    
    let quizHtml = '';
    quiz.questions.forEach((question, index) => {
        quizHtml += `
            <div class="quiz-question">
                <h4>Question ${index + 1}: ${question.question}</h4>
                <div class="quiz-options">
                    ${question.options.map((option, optIndex) => `
                        <label class="quiz-option" data-question="${index}" data-option="${optIndex}">
                            <input type="radio" name="question_${index}" value="${optIndex}">
                            ${option}
                        </label>
                    `).join('')}
                </div>
                <div class="quiz-explanation hidden" id="explanation_${index}">
                    ${question.explanation}
                </div>
            </div>
        `;
    });
    
    quizHtml += `
        <div class="quiz-actions">
            <button class="btn btn--primary" onclick="submitQuiz(${quizId})">Submit Quiz</button>
        </div>
    `;
    
    content.innerHTML = quizHtml;
    modal.classList.remove('hidden');
}

function submitQuiz(quizId) {
    const quiz = sampleData.quizzes.find(q => q.id === quizId);
    if (!quiz) return;
    
    let score = 0;
    quiz.questions.forEach((question, index) => {
        const selected = document.querySelector(`input[name="question_${index}"]:checked`);
        const options = document.querySelectorAll(`[data-question="${index}"]`);
        const explanation = document.getElementById(`explanation_${index}`);
        
        if (selected) {
            const selectedValue = parseInt(selected.value);
            if (selectedValue === question.correct) {
                score++;
                options[selectedValue].classList.add('correct');
            } else {
                options[selectedValue].classList.add('incorrect');
                options[question.correct].classList.add('correct');
            }
        } else {
            options[question.correct].classList.add('correct');
        }
        
        explanation.classList.remove('hidden');
    });
    
    showToast(`Quiz completed! Score: ${score}/${quiz.questions.length}`);
}

// View material function
function viewMaterial(url, type) {
    if (type === 'pdf' || type === 'image') {
        window.open(url, '_blank');
    } else {
        downloadFile(url, `material.${type}`);
    }
}

// Course view function
function viewCourse(courseId) {
    const course = sampleData.subjects.find(s => s.id === courseId);
    if (!course) return;
    
    // Switch to materials tab and filter by course
    if (currentUser && currentUser.role === 'student') {
        switchStudentTab('materials');
        loadStudentMaterials(courseId);
    }
}

// Load data functions
function loadTeacherData() {
    // Load classes for dropdown
    const classSelect = document.getElementById('classSelect');
    if (classSelect) {
        classSelect.innerHTML = '<option value="">Select Class</option>';
        sampleData.subjects.forEach(subject => {
            const option = document.createElement('option');
            option.value = subject.id;
            option.textContent = `${subject.code} - ${subject.name}`;
            classSelect.appendChild(option);
        });
    }
    
    // Load materials
    loadMaterials();
    
    // Load recordings
    loadRecordings();
}

function loadMaterials() {
    const materialsList = document.getElementById('materialsList');
    if (!materialsList) return;
    
    materialsList.innerHTML = '';
    
    sampleData.subjects.forEach(subject => {
        subject.materials.forEach(material => {
            const card = createMaterialCard(material);
            materialsList.appendChild(card);
        });
    });
}

function loadRecordings() {
    const recordingsList = document.getElementById('recordingsList');
    if (!recordingsList) return;
    
    recordingsList.innerHTML = '';
    
    sampleData.recordings.forEach(recording => {
        const card = createRecordingCard(recording);
        recordingsList.appendChild(card);
    });
}

function loadStudentData() {
    // Load courses
    const coursesList = document.getElementById('coursesList');
    if (coursesList) {
        coursesList.innerHTML = '';
        sampleData.subjects.forEach(course => {
            const card = createCourseCard(course);
            coursesList.appendChild(card);
        });
    }
    
    // Load recordings
    const studentRecordingsList = document.getElementById('studentRecordingsList');
    if (studentRecordingsList) {
        studentRecordingsList.innerHTML = '';
        sampleData.recordings.forEach(recording => {
            const card = createRecordingCard(recording);
            studentRecordingsList.appendChild(card);
        });
    }
    
    // Load materials
    loadStudentMaterials();
    
    // Load quizzes
    const quizzesList = document.getElementById('quizzesList');
    if (quizzesList) {
        quizzesList.innerHTML = '';
        sampleData.quizzes.forEach(quiz => {
            const card = createQuizCard(quiz);
            quizzesList.appendChild(card);
        });
    }
}

function loadStudentMaterials(courseId = null) {
    const materialsList = document.getElementById('studentMaterialsList');
    if (!materialsList) return;
    
    materialsList.innerHTML = '';
    
    let subjects = sampleData.subjects;
    if (courseId) {
        subjects = subjects.filter(s => s.id === courseId);
    }
    
    subjects.forEach(subject => {
        subject.materials.forEach(material => {
            const card = createMaterialCard(material);
            materialsList.appendChild(card);
        });
    });
}

// Tab switching functions
function switchTab(tabName) {
    console.log('Switching to tab:', tabName);
    
    // Hide all tab contents
    const tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(tab => {
        tab.classList.remove('active');
        tab.classList.add('hidden');
    });
    
    // Show selected tab
    const targetTab = document.getElementById(tabName + 'Tab');
    if (targetTab) {
        targetTab.classList.remove('hidden');
        targetTab.classList.add('active');
    }
    
    // Update tab buttons
    const tabButtons = document.querySelectorAll('.tab-btn');
    tabButtons.forEach(btn => {
        btn.classList.remove('active');
    });
    
    const activeButton = document.querySelector(`[data-tab="${tabName}"]`);
    if (activeButton) {
        activeButton.classList.add('active');
    }
}

function switchStudentTab(tabName) {
    console.log('Switching to student tab:', tabName);
    
    // Hide all student tab contents
    const tabContents = document.querySelectorAll('.student-tab-content');
    tabContents.forEach(tab => {
        tab.classList.remove('active');
        tab.classList.add('hidden');
    });
    
    // Show selected tab
    const tabId = tabName === 'courses' ? 'coursesTab' : 
                  tabName === 'recordings' ? 'studentRecordingsTab' :
                  tabName === 'materials' ? 'studentMaterialsTab' : 'quizzesTab';
    
    const targetTab = document.getElementById(tabId);
    if (targetTab) {
        targetTab.classList.remove('hidden');
        targetTab.classList.add('active');
    }
    
    // Update tab buttons
    const tabButtons = document.querySelectorAll('.student-tab-btn');
    tabButtons.forEach(btn => {
        btn.classList.remove('active');
    });
    
    const activeButton = document.querySelector(`[data-tab="${tabName}"]`);
    if (activeButton) {
        activeButton.classList.add('active');
    }
}

// Initialize application
function initApp() {
    console.log('Initializing app...');
    
    // Login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const role = document.getElementById('roleSelect').value;
            const email = document.getElementById('emailInput').value;
            
            console.log('Login attempt:', role, email);
            
            // Find user
            const user = sampleData.users.find(u => u.email === email && u.role === role);
            
            if (user) {
                currentUser = user;
                console.log('User found:', currentUser);
                
                if (role === 'teacher') {
                    const nameEl = document.getElementById('teacherName');
                    if (nameEl) nameEl.textContent = user.name;
                    showScreen('teacherDashboard');
                    loadTeacherData();
                } else {
                    const nameEl = document.getElementById('studentName');
                    if (nameEl) nameEl.textContent = user.name;
                    showScreen('studentDashboard');
                    loadStudentData();
                }
            } else {
                alert('Invalid credentials. Please use the sample credentials provided.');
            }
        });
    }
    
    // Logout buttons with proper event handling
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Teacher logout clicked');
            currentUser = null;
            if (localStream) {
                stopCamera();
            }
            showScreen('loginScreen');
            
            // Reset forms
            const loginForm = document.getElementById('loginForm');
            if (loginForm) loginForm.reset();
        });
    }
    
    const studentLogoutBtn = document.getElementById('studentLogoutBtn');
    if (studentLogoutBtn) {
        studentLogoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Student logout clicked');
            currentUser = null;
            showScreen('loginScreen');
            
            // Reset forms
            const loginForm = document.getElementById('loginForm');
            if (loginForm) loginForm.reset();
        });
    }
    
    // Camera controls
    const toggleCameraBtn = document.getElementById('toggleCamera');
    if (toggleCameraBtn) {
        toggleCameraBtn.addEventListener('click', function() {
            if (isCameraOn) {
                stopCamera();
            } else {
                initCamera();
            }
        });
    }
    
    const toggleMicBtn = document.getElementById('toggleMic');
    if (toggleMicBtn) {
        toggleMicBtn.addEventListener('click', function() {
            isMicOn = !isMicOn;
            const btn = document.getElementById('toggleMic');
            btn.textContent = isMicOn ? '🔇 Mic' : '🎤 Mic';
            btn.className = isMicOn ? 'btn btn--primary' : 'btn btn--secondary';
        });
    }
    
    const shareScreenBtn = document.getElementById('shareScreen');
    if (shareScreenBtn) {
        shareScreenBtn.addEventListener('click', function() {
            showToast('Screen sharing initiated!');
        });
    }
    
    const startClassBtn = document.getElementById('startClass');
    if (startClassBtn) {
        startClassBtn.addEventListener('click', function() {
            const selectedClass = document.getElementById('classSelect').value;
            if (selectedClass && isCameraOn) {
                showToast('Live class started successfully!');
            } else if (!selectedClass) {
                alert('Please select a class first.');
            } else {
                alert('Please turn on your camera first.');
            }
        });
    }
    
    // Tab switching - Teacher tabs
    const tabButtons = document.querySelectorAll('.tab-btn');
    tabButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const tab = this.getAttribute('data-tab');
            console.log('Tab clicked:', tab);
            switchTab(tab);
        });
    });
    
    // Tab switching - Student tabs
    const studentTabButtons = document.querySelectorAll('.student-tab-btn');
    studentTabButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const tab = this.getAttribute('data-tab');
            console.log('Student tab clicked:', tab);
            switchStudentTab(tab);
        });
    });
    
    // Modal close buttons
    const closeModalBtn = document.getElementById('closeModal');
    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', function() {
            const recordingModal = document.getElementById('recordingModal');
            if (recordingModal) {
                recordingModal.classList.add('hidden');
                // Stop any playing media
                const video = document.getElementById('recordingVideo');
                const audio = document.getElementById('recordingAudio');
                if (video) video.pause();
                if (audio) audio.pause();
            }
        });
    }
    
    const closeQuizModalBtn = document.getElementById('closeQuizModal');
    if (closeQuizModalBtn) {
        closeQuizModalBtn.addEventListener('click', function() {
            const quizModal = document.getElementById('quizModal');
            if (quizModal) {
                quizModal.classList.add('hidden');
            }
        });
    }
    
    // Modal overlay clicks
    const modalOverlays = document.querySelectorAll('.modal-overlay');
    modalOverlays.forEach(overlay => {
        overlay.addEventListener('click', function() {
            this.parentElement.classList.add('hidden');
        });
    });
    
    // Setup file upload
    setupFileUpload();
    
    console.log('App initialization complete');
}

// Global functions for button clicks (exposed to window for onclick handlers)
window.downloadFile = downloadFile;
window.viewMaterial = viewMaterial;
window.playRecording = playRecording;
window.startQuiz = startQuiz;
window.submitQuiz = submitQuiz;
window.viewCourse = viewCourse;

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', initApp);